/***************  COLOR SHEMES FILES FOR PHP STORM.  ************************/

All the custom made skins are added here. Some are by me,
some are which I found interesting while browsing around.

Thanks to all those who took effort making the custom skins.

USAGE :

  Copy it in the /home/webonise/.WebIde70/config/colors
  (THE .WebIde70 dir name varies with the version of the PHPSTORM,
  e.g. it is .WebIde50 for PHPSTORM 5. So put the files accordingly.)


- Enjoy!
